package dao;

import dto.Patient;

public class PatientDaoImpl implements PatientDao {

	@Override
	public Patient selectPatient(String pemail) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertPatient(Patient patient) throws Exception {
		// TODO Auto-generated method stub

	}

}
